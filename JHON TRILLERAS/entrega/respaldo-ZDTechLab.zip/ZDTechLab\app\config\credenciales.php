<?php
return [
  'host' => '127.0.0.1',
  'bd' => 'zdtechlab_jt',
  'usuario' => 'root',
  'clave' => '',
  'puerto' => 3306,
];
