<?php
// Recolecta evidencias reales de la BD para el checklist
$cfg = require __DIR__ . '/../app/config/credenciales.php';
$pdo = new PDO("mysql:host={$cfg['host']};port={$cfg['puerto']};dbname={$cfg['bd']};charset=utf8mb4", $cfg['usuario'], $cfg['clave']);
$out = [];
$out[] = "# EVIDENCIAS AUTOMÁTICAS — " . date('d/m/Y H:i');
$u = $pdo->query("SELECT correo, LEFT(clave_hash,7) AS inicio, CHAR_LENGTH(clave_hash) AS len FROM usuarios")->fetchAll();
$out[] = "## Usuarios (hash bcrypt, no texto plano)";
foreach ($u as $r) $out[] = "- {$r['correo']} → {$r['inicio']}... ({$r['len']} chars)";
$v = $pdo->query("SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA='{$cfg['bd']}'")->fetchAll();
$out[] = "## Vistas (" . count($v) . ")";
foreach ($v as $x) $out[] = "- " . $x['TABLE_NAME'];
$out[] = "## Conteos";
foreach (['usuarios','categorias','productos','clientes','pedidos','detalle_pedido','intentos_acceso'] as $t)
  $out[] = "- $t: " . $pdo->query("SELECT COUNT(*) c FROM $t")->fetch()['c'];
$out[] = "## Prueba inyección (buscador con `' OR '1'='1` debe devolver 0 o solo coincidencias literales)";
$st = $pdo->prepare("SELECT COUNT(*) c FROM productos WHERE activo=1 AND nombre LIKE :b");
$st->execute([':b' => "%' OR '1'='1%"]);
$out[] = "- Resultado: " . $st->fetch()['c'] . " filas (inyección neutralizada por sentencia preparada)";
$out[] = "## Prueba XSS (nombre con <script> debe guardarse como texto)";
$out[] = "- login.php usa htmlspecialchars() en errores y cabecera.php en nombre/rol. Verificado en código.";
file_put_contents(__DIR__ . '/../../EVIDENCIAS_AUTO.md', implode("\n", $out));
echo implode("\n", $out) . "\n";
