<?php
// Genera logo.png simple (cuadro verde JT) sin GD: PNG truecolor 240x72 escrito a mano
$w = 240; $h = 72;
$raw = '';
for ($y = 0; $y < $h; $y++) {
  $raw .= "\x00";
  for ($x = 0; $x < $w; $x++) {
    if ($x < 72) { $raw .= "\x39\xA9\x00"; }       // verde institucional
    elseif ($x < 76) { $raw .= "\xFF\xFF\xFF"; }    // separador
    else { $raw .= "\xF7\xF8\xF6"; }                // fondo claro
  }
}
$ihdr = pack('N', $w) . pack('N', $h) . chr(8) . chr(2) . chr(0) . chr(0) . chr(0);
$png = "\x89PNG\r\n\x1a\n";
$chunk = function($type, $data) {
  $c = $type . $data;
  return pack('N', strlen($data)) . $c . pack('N', crc32($c));
};
$png .= $chunk('IHDR', $ihdr);
$png .= $chunk('IDAT', gzcompress($raw));
$png .= $chunk('IEND', '');
file_put_contents(__DIR__ . '/../assets/img/logo.png', $png);
echo "logo.png OK " . strlen($png) . " bytes\n";
