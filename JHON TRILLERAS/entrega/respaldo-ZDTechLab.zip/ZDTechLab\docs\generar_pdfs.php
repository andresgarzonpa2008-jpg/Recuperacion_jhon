<?php
// Mini librería PDF (texto latino, Helvetica) + generadores de reportes con datos reales
declare(strict_types=1);
function pdf_simple(string $titulo, array $lineas, string $dest): void {
  $txt = '';
  $y = 800;
  $esc = function($s) {
    $s = (string)$s;
    $t = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $s);
    if ($t === false) $t = preg_replace('/[^\x20-\x7E]/', '?', $s);
    return str_replace(['\\','(',')'], ['\\\\','\\(','\\)'], $t);
  };
  $ops = "BT /F1 16 Tf 40 $y Td ({$esc($titulo)}) Tj ET\n";
  $y -= 26;
  $ops .= "BT /F1 9 Tf 40 $y Td (JT.TechLab - Jhon Trilleras - SENA ADSI - " . date('d/m/Y H:i') . ") Tj ET\n";
  $y -= 20;
  foreach ($lineas as $l) {
    if ($y < 50) break; // una página (suficiente para evidencia)
    $ops .= "BT /F1 9 Tf 40 $y Td ({$esc($l)}) Tj ET\n";
    $y -= 13;
  }
  $objs = [];
  $objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  $objs[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
  $objs[3] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>";
  $objs[4] = "<< /Length " . strlen($ops) . " >>\nstream\n$ops\nendstream";
  $objs[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
  $pdf = "%PDF-1.4\n";
  $off = [0]; $pos = strlen($pdf);
  for ($i = 1; $i <= 5; $i++) { $off[$i] = $pos; $s = "$i 0 obj\n{$objs[$i]}\nendobj\n"; $pdf .= $s; $pos += strlen($s); }
  $pdf .= "xref\n0 6\n0000000000 65535 f \n";
  for ($i = 1; $i <= 5; $i++) $pdf .= sprintf("%010d 00000 n \n", $off[$i]);
  $pdf .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n$pos\n%%EOF";
  file_put_contents($dest, $pdf);
  echo "PDF OK: $dest\n";
}

$cfg = require __DIR__ . '/../app/config/credenciales.php';
$pdo = new PDO("mysql:host={$cfg['host']};port={$cfg['puerto']};dbname={$cfg['bd']};charset=utf8mb4",
  $cfg['usuario'], $cfg['clave'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);

$base = __DIR__ . '/../../entrega';
if (!is_dir($base)) mkdir($base, 0777, true);

// 1. Ventas por categoría (datos reales)
$filas = $pdo->query("SELECT categoria,unidades,total_vendido FROM v_ventas_categoria WHERE total_vendido>0 ORDER BY total_vendido DESC")->fetchAll();
$total = array_sum(array_column($filas, 'total_vendido'));
$L = ["Reporte N. R-2026-0148 - Ventas por categoria - Filtros: 2026-01-01 a ".date('Y-m-d')." - Estado: confirmado", str_repeat('-', 90)];
foreach ($filas as $f) $L[] = sprintf("%-18s %8d und  $ %12s", $f['categoria'], $f['unidades'], number_format((float)$f['total_vendido'], 0, ',', '.'));
$L[] = str_repeat('-', 90);
$L[] = "TOTAL GENERAL: $ " . number_format($total, 0, ',', '.');
$L[] = "Generado por: Administrador JT - Documento interno - Pagina 1 de 1";
pdf_simple('Reporte de ventas por categoria', $L, "$base/reporte-ventas-categoria.pdf");

// 2. Inventario / stock crítico
$st = $pdo->query("SELECT * FROM v_stock_critico")->fetchAll();
$L2 = ["Reporte de inventario con stock critico (vista v_stock_critico)", str_repeat('-', 90)];
foreach ($st as $s) $L2[] = sprintf("%-24s %-14s stock %3d / min %2d  $ %s", substr($s['nombre'],0,24), substr($s['categoria'],0,14), $s['stock'], $s['stock_minimo'], number_format((float)$s['precio'],0,',','.'));
if (!$st) $L2[] = "(Sin productos en critico al momento de generar)";
$L2[] = "Total items en critico: " . count($st);
pdf_simple('Reporte de inventario - stock critico', $L2, "$base/reporte-inventario-critico.pdf");

// 3. Pedidos por cliente
$top = $pdo->query("SELECT * FROM v_clientes_top ORDER BY total_comprado DESC LIMIT 10")->fetchAll();
$L3 = ["Reporte de pedidos por cliente (vista v_clientes_top)", str_repeat('-', 90)];
foreach ($top as $t) $L3[] = sprintf("%-22s %-12s %3d pedidos  $ %s", substr($t['nombre'],0,22), substr($t['documento'],0,12), $t['pedidos'], number_format((float)$t['total_comprado'],0,',','.'));
pdf_simple('Reporte de pedidos por cliente', $L3, "$base/reporte-pedidos-cliente.pdf");

// 4. Bitácora 15 días
$bit = file(__DIR__ . '/../../BITACORA_15_DIAS.md', FILE_IGNORE_NEW_LINES);
$L4 = [];
foreach ($bit as $b) { $b = trim($b); if ($b === '' || str_starts_with($b, '# ')) continue; $L4[] = substr($b, 0, 110); }
pdf_simple('Bitacora 15 dias - Jhon Trilleras', $L4, "$base/bitacora-15-dias.pdf");

// 5. Día 01 color
pdf_simple('Dia 01 - Teoria del color', [
  "Circulo cromatico 12 matices dibujado en bitacora (rojo-naranja-amarillo-verde-azul-violeta).",
  "Esquema elegido: complementario dividido (verde #39A900 + acento naranja #F08A00).",
  "Regla 60-30-10: 60% neutros #F7F8F6, 30% marca #1F5E14, 10% accion/acento.",
  "Escala hsl(100,...): 900/12%, 700/22%, 500/33% base, 300/62%, 100/90%.",
  "Apps analizadas: banco (analogo azul), ERP (monocromatico gris-azul), tienda (complementario).",
], "$base/dia01-color.pdf");
echo "TODO LISTO\n";
